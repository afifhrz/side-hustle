start to build the python environtment at upper directory

``` bash
python -m virtualenv virtenv
```

start the env using this powershell scripts

``` bash
.\virtenv\Scripts\activate
```

install the requirements library
``` bash
cd final_project
pip install -r requirements.txt
```